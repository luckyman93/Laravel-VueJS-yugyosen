<template>
  <footer class="footer-lender">
    <ul class="footer-menus">
      <li>
        <router-link to="#" class="footer-menu">管理画面TOP</router-link>
        <router-link to="#" class="footer-menu">優先表示解約</router-link>
      </li>
      <li>
        <router-link to="#" class="footer-menu">ログアウト</router-link>
        <router-link to="#" class="footer-menu">問合せ</router-link>
        <router-link to="#" class="footer-menu">遊漁船サーチへ</router-link>
      </li>
    </ul>

    <div class="footer-logo">
      <router-link to="/"><img class="mw-100" src="/images/common/logo_footer.svg"/></router-link>
    </div>
  </footer>
</template>
<script>
export default {}
</script>
