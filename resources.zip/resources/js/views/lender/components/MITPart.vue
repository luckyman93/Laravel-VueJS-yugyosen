<template>
  <section class="main-lineup">
    <h3 class="main-lineup-headline">
      <span class="main-lineup-headline-caption"><span>遊漁船業者様のIT部門は</span></span>
      <img class="main-lineup-headline-logo" src="/images/lender/logo_technav.png" />
      にお任せ！！
    </h3>
    <div class="main-lineup-items">
      <dl class="main-lineup-item">
        <dt class="main-lineup-item-copy">ホームページは今の時代に欠かせない</dt>
        <dd class="main-lineup-item-banner ex-website">
          <a href="#">
            <img class="ex-website" src="/images/lender/icon_website.svg" />
            <span>ホームページ制作</span>
          </a>
        </dd>
      </dl>
      <dl class="main-lineup-item">
        <dt class="main-lineup-item-copy">今ホームページより重要と言われる</dt>
        <dd class="main-lineup-item-banner ex-google">
          <a href="#">
            <img class="ex-google" src="/images/lender/icon_google.svg" />
            <span>Google My business</span>
          </a>
        </dd>
      </dl>
      <dl class="main-lineup-item">
        <dt class="main-lineup-item-copy">若者向けの発信をしていきたいなら</dt>
        <dd class="main-lineup-item-banner ex-sns">
          <a href="#">
            <img class="ex-facebook" src="/images/lender/icon_facebook.svg" />
            <img class="ex-instagram" src="/images/lender/icon_instagram.svg" />
            <span>SNS運用代行</span>
            <img class="ex-twitter" src="/images/lender/icon_twitter.svg" />
          </a>
        </dd>
      </dl>
      <dl class="main-lineup-item">
        <dt class="main-lineup-item-copy">リピーターを囲い込むなら</dt>
        <dd class="main-lineup-item-banner ex-line">
          <a href="#">
            <img class="ex-instagram" src="/images/lender/icon_instagram.svg" />
            <span>公式LINE構築代行</span>
          </a>
        </dd>
      </dl>
    </div>
  </section>
</template>

<script>
export default {}
</script>
