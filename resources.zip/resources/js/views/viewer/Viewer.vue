<template>
  <div>
    <RouterView />
  </div>
</template>

<script>
export default {
  components: {},
  data: () => ({}),
  methods: {},
}
</script>
