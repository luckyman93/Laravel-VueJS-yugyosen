<template>
  <router-link to="#" class="ex-wanted">
    <dl>
      <dt class="ex-wanted-title">遊漁船情報募集中</dt>
      <dd>
        <div class="ex-wanted-current">現在</div>
        <div class="ex-wanted-count">
          <span class="ex-wanted-count-number">000</span>
          <span class="ex-wanted-count-unit">艘</span>
        </div>
      </dd>
    </dl>
  </router-link>
</template>
<script>
export default {}
</script>
