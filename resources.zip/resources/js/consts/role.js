// 役割
const ADMIN = 1
const LENDER = 2
const VIEWER = 3

export default {
  TYPE: {
    ADMIN,
    LENDER,
    VIEWER,
  },
}
