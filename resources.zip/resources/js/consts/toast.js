export default {
  SUCCESS: {
    CREATED: '新規登録しました',
    UPDATED: '更新しました',
    DELETED: '削除しました',
    UPDATED_PASSWORD: 'パスワードを更新しました',
    REISSUE_PASSWORD: 'パスワードを再発行いたしました',
    UPDATED_EMAIL: 'メールアドレスを更新しました',
    REISSUE_EMAIL: 'メールアドレスを再発行いたしました',
  },
}
