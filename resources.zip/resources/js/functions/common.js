export default {
  // /*-------------------------------------------*/
  // /* チェックボックス
  // /*-------------------------------------------*/
  // filterCheckBoxSelectedIds(id, selectedIds) {
  //   if (selectedIds.includes(id)) {
  //     selectedIds = selectedIds.filter(n => n !== id)
  //   } else {
  //     selectedIds.push(id)
  //   }
  //   return selectedIds
  // },
}
