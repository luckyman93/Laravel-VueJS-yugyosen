const apiBaseUrl = `${process.env.MIX_BASE_URL}/api`

export default {
  apiBaseUrl,
}
