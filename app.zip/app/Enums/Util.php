<?php

namespace App\Enums;

use BenSampo\Enum\Enum;

final class Util extends Enum
{
    const PAGINATE_COUNT = 2000;
    const PAGINATE_COUNT_POST = 2000;
    const PAGINATE_COUNT_BOAT = 2000;
}
