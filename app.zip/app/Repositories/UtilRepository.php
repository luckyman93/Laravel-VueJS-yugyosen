<?php

namespace App\Repositories;

use Illuminate\Support\Facades\Log;

class UtilRepository
{
    protected $model;

    public function __construct()
    {
    }
}
